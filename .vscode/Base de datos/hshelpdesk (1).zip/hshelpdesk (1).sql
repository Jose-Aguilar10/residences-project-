-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 02-06-2023 a las 04:37:37
-- Versión del servidor: 10.4.27-MariaDB
-- Versión de PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `hshelpdesk`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `filtrar_tickett` (IN `tick_titulo` VARCHAR(50), IN `cat_id` INT, IN `prio_id` INT)   BEGIN
 IF tick_titulo = '' THEN            
 SET tick_titulo = NULL;
 END IF; 
 
  IF cat_id = '' THEN            
 SET cat_id = NULL;
 END IF; 
 
  IF prio_id = '' THEN  
 SET prio_id = NULL;
 END IF; 
 
SELECT
tm_ticket.tick_id,
tm_ticket.usu_id,
tm_ticket.cat_id,
tm_ticket.tick_titulo,
tm_ticket.tick_descrip,
tm_ticket.tick_estado,
tm_ticket.fech_crea,
tm_ticket.fech_cierre,
tm_ticket.usu_asig,
tm_ticket.fech_asig,
tm_usuario.usu_nom,
tm_usuario.usu_ape,
tm_categoria.cat_nom,
tm_ticket.prio_id,
tm_prioridad.prio_nom
FROM 
tm_ticket
INNER join tm_categoria on tm_ticket.cat_id = tm_categoria.cat_id
INNER join tm_usuario on tm_ticket.usu_id = tm_usuario.usu_id
INNER join tm_prioridad on tm_ticket.prio_id = tm_prioridad.prio_id
WHERE
tm_ticket.est = 1
AND tm_ticket.tick_titulo like IFNULL(tick_titulo,tm_ticket.tick_titulo)
AND tm_ticket.cat_id =  IFNULL(cat_id,tm_ticket.cat_id)
AND tm_ticket.prio_id = IFNULL(prio_id,tm_ticket.prio_id);

END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `td_documento`
--

CREATE TABLE `td_documento` (
  `doc_id` int(11) NOT NULL,
  `tick_id` int(11) NOT NULL,
  `doc_nom` varchar(400) NOT NULL,
  `fech_crea` datetime NOT NULL,
  `est` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `td_documento_detalle`
--

CREATE TABLE `td_documento_detalle` (
  `det_id` int(11) NOT NULL,
  `tickd_id` int(11) NOT NULL,
  `det_nom` varchar(200) NOT NULL,
  `est` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `td_ticketdetalle`
--

CREATE TABLE `td_ticketdetalle` (
  `tickd_id` int(11) NOT NULL,
  `tick_id` int(11) NOT NULL,
  `usu_id` int(11) NOT NULL,
  `tickd_descrip` mediumtext NOT NULL,
  `fech_crea` datetime NOT NULL,
  `est` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `td_ticketdetalle`
--

INSERT INTO `td_ticketdetalle` (`tickd_id`, `tick_id`, `usu_id`, `tickd_descrip`, `fech_crea`, `est`) VALUES
(1, 9, 1, '<p>Prueba 2</p>', '2023-04-24 12:09:10', 1),
(2, 9, 2, '<p>Respuesta soporte</p>', '2023-04-24 13:51:37', 1),
(3, 32, 2, '<p>Ok</p>', '2023-05-03 12:22:38', 1),
(4, 34, 11, 'Ticket Re-Abierto...', '2023-05-04 23:51:23', 1),
(5, 38, 11, 'Ticket Re-Abierto...', '2023-05-09 10:42:06', 1),
(6, 34, 11, '<p>Prueba noti</p>', '2023-05-20 00:27:46', 1),
(7, 34, 1, '<p>respuesta prueba noti</p>', '2023-05-20 00:28:04', 1),
(8, 34, 1, '<p>Prueba noti</p>', '2023-05-20 00:28:37', 1),
(9, 34, 1, '<p>prueba 2</p>', '2023-05-20 00:28:57', 1),
(10, 34, 1, '<p>prueba nueva de notificacion</p>', '2023-05-26 09:36:33', 1),
(11, 34, 11, '<p>prueba</p>', '2023-05-26 09:37:23', 1),
(12, 34, 11, '<p>hola</p><p><br></p>', '2023-05-26 09:38:00', 1),
(13, 41, 11, '<p>Prueba 2</p>', '2023-05-26 09:41:17', 1),
(14, 41, 11, '<p>prueba</p>', '2023-05-26 09:43:41', 1),
(15, 41, 1, '<p>hola</p>', '2023-05-26 09:46:20', 1),
(16, 41, 11, '<p>hola</p>', '2023-05-26 09:46:36', 1),
(17, 41, 1, '<p>hola</p>', '2023-05-26 09:46:42', 1),
(18, 41, 1, '<p>hola</p>', '2023-05-26 09:47:19', 1),
(19, 41, 11, '<p>hola</p>', '2023-05-26 09:47:25', 1),
(20, 41, 11, '<p>hola</p>', '2023-05-26 09:47:40', 1),
(21, 41, 1, '<p>hola</p><p><br></p>', '2023-05-26 09:47:49', 1),
(22, 41, 11, '<p>hola</p>', '2023-05-26 09:48:54', 1),
(23, 41, 1, '<p>hola</p>', '2023-05-26 09:49:01', 1),
(24, 41, 1, '<p>hola</p>', '2023-05-26 09:49:12', 1),
(25, 41, 1, '<p>hola</p>', '2023-05-26 09:49:26', 1),
(26, 41, 11, '<p>hola</p>', '2023-05-26 09:49:40', 1),
(27, 41, 1, '<p>hola</p>', '2023-05-26 09:49:45', 1),
(28, 42, 11, '<p>hola</p>', '2023-05-26 19:04:04', 1),
(29, 34, 11, '<p>hola</p>', '2023-05-27 23:53:35', 1),
(30, 34, 1, '<p>hola</p>', '2023-05-27 23:54:12', 1),
(31, 34, 11, '<p>hola</p>', '2023-05-27 23:55:05', 1),
(32, 34, 1, '<p>hola</p>', '2023-05-27 23:55:20', 1),
(33, 34, 11, '<p>hola</p>', '2023-05-27 23:58:56', 1),
(34, 34, 11, '<p>hola2</p>', '2023-05-27 23:59:18', 1),
(35, 34, 11, '<p>hola</p>', '2023-05-28 00:03:38', 1),
(36, 34, 1, '<p>holaaa</p>', '2023-05-28 00:04:16', 1),
(37, 34, 11, '<p>holaaa</p><p><br></p>', '2023-05-28 00:04:53', 1),
(38, 34, 11, '<p>holaa</p>', '2023-05-28 00:05:56', 1),
(39, 34, 1, '<p>holaaa</p>', '2023-05-28 00:14:42', 1),
(40, 34, 11, '<p>holaaa</p>', '2023-05-28 00:15:35', 1),
(41, 43, 11, 'test', '2023-05-28 12:29:10', 1),
(42, 43, 11, '<p>prueba</p>', '2023-05-28 14:45:18', 1),
(43, 43, 1, '<p>hola</p>', '2023-05-28 14:47:19', 1),
(44, 43, 11, '<p>holaa</p>', '2023-05-28 14:48:03', 1),
(45, 43, 1, '<p>holaa2</p>', '2023-05-28 14:48:16', 1),
(46, 43, 11, '<p>hola 3</p>', '2023-05-28 14:48:33', 1),
(47, 43, 1, '<p>hola</p>', '2023-05-28 15:14:57', 1),
(48, 43, 1, '<p>prueba 2</p>', '2023-05-28 15:17:08', 1),
(49, 43, 1, '<p>prueba url</p>', '2023-05-28 15:18:59', 1),
(50, 43, 1, '<p>hola</p>', '2023-05-28 15:28:03', 1),
(51, 44, 11, '<p>Prueba respuesta</p>', '2023-05-29 23:12:24', 1),
(52, 44, 1, '<p>Respuesta prueba&nbsp;</p>', '2023-05-29 23:12:43', 1),
(53, 45, 1, '<p>prueba</p>', '2023-05-30 00:24:12', 1),
(54, 45, 11, '<p>prueba 2</p>', '2023-05-30 00:24:26', 1),
(55, 45, 11, '<p>prueba 2</p>', '2023-05-30 12:59:05', 1),
(56, 48, 11, 'Ticket Re-Abierto...', '2023-05-30 13:11:48', 1),
(57, 49, 11, '<p>hola</p>', '2023-05-31 11:33:13', 1),
(58, 49, 11, '<p>holaa</p>', '2023-05-31 11:35:29', 1),
(59, 49, 11, '<p>holaa</p>', '2023-05-31 11:38:54', 1),
(60, 49, 1, '<p>holaa</p>', '2023-05-31 11:40:18', 1),
(61, 49, 11, '<p>holaaa</p>', '2023-05-31 11:40:54', 1),
(62, 49, 1, '<p>holaaa</p>', '2023-05-31 11:48:28', 1),
(63, 49, 11, '<p>prueba</p>', '2023-05-31 11:50:20', 1),
(64, 49, 1, '<p>hola</p>', '2023-05-31 11:52:03', 1),
(65, 49, 1, '<p>holaa</p>', '2023-05-31 12:03:56', 1),
(66, 49, 1, '<p>hola</p>', '2023-05-31 12:06:13', 1),
(67, 49, 1, '<p>hola</p>', '2023-05-31 12:07:44', 1),
(68, 49, 1, '<p>hola</p>', '2023-05-31 12:08:34', 1),
(69, 49, 1, '<p>hola</p><p><br></p>', '2023-05-31 12:14:35', 1),
(70, 49, 1, '<p>hola</p>', '2023-05-31 14:47:14', 1),
(71, 49, 1, '<p>holaa</p><p><br></p>', '2023-05-31 14:51:26', 1),
(72, 49, 1, '<p>hola</p>', '2023-05-31 15:16:31', 1),
(73, 49, 1, '<p>hola</p>', '2023-05-31 22:01:29', 1),
(74, 49, 1, '<p>holaa</p>', '2023-05-31 22:01:48', 1),
(75, 49, 11, '<p>holaaa</p>', '2023-05-31 22:03:04', 1),
(76, 49, 1, '<p>hola</p>', '2023-05-31 22:06:16', 1),
(77, 49, 1, '<p>hola</p>', '2023-05-31 23:19:38', 1),
(78, 49, 1, '<p>hola</p>', '2023-05-31 23:23:02', 1),
(79, 49, 1, '<p>123</p>', '2023-05-31 23:35:08', 1),
(80, 49, 1, '<p>holaa</p>', '2023-05-31 23:37:25', 1),
(81, 49, 11, '<p>holaa</p><p><br></p>', '2023-05-31 23:38:33', 1),
(82, 49, 1, '<p>hola</p>', '2023-05-31 23:59:23', 1),
(83, 49, 11, '<p>hola</p>', '2023-06-01 00:00:03', 1),
(84, 49, 1, '<p>holaaa</p>', '2023-06-01 00:00:49', 1),
(85, 49, 1, '<p>holaaaa</p>', '2023-06-01 09:38:54', 1),
(86, 49, 1, '<p>hola</p><p><br></p>', '2023-06-01 09:54:49', 1),
(87, 49, 1, '<p>holaa</p>', '2023-06-01 10:30:21', 1),
(88, 49, 1, '<p>hola</p>', '2023-06-01 10:35:03', 1),
(89, 49, 1, '<p>hoaaa</p>', '2023-06-01 10:37:39', 1),
(90, 49, 1, '<p>holaa</p>', '2023-06-01 11:24:04', 1),
(91, 49, 1, '<p>prueba</p>', '2023-06-01 12:32:21', 1),
(92, 49, 1, '<p>holaaa</p>', '2023-06-01 13:05:01', 1),
(93, 49, 1, '<p>hola</p>', '2023-06-01 13:09:06', 1),
(94, 49, 11, '<p>holaaa</p>', '2023-06-01 13:09:25', 1),
(95, 49, 11, '<p>holaa</p>', '2023-06-01 13:10:15', 1),
(96, 49, 1, '<p>holaa</p>', '2023-06-01 14:44:05', 1),
(97, 49, 1, '<p>hola</p>', '2023-06-01 14:55:16', 1),
(98, 49, 1, '<p>Holaa</p>', '2023-06-01 15:13:59', 1),
(99, 49, 1, '<p>holaaa</p>', '2023-06-01 16:30:54', 1),
(100, 49, 1, '<p>hola</p>', '2023-06-01 20:28:18', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_categoria`
--

CREATE TABLE `tm_categoria` (
  `cat_id` int(11) NOT NULL,
  `cat_nom` varchar(150) NOT NULL,
  `est` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `tm_categoria`
--

INSERT INTO `tm_categoria` (`cat_id`, `cat_nom`, `est`) VALUES
(1, 'Hardware', 0),
(2, 'Software ', 0),
(3, 'Insidencia', 0),
(4, 'Petición de servicio', 0),
(5, 'Recepción ', 1),
(6, 'Villas', 1),
(7, 'Rest. Caracoles', 1),
(8, 'Rest. Nude', 1),
(9, 'Rest. Italiano', 1),
(10, 'Toallero', 1),
(11, 'Lobby', 1),
(12, 'Finanzas', 1),
(13, 'Villas 2', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_departamento`
--

CREATE TABLE `tm_departamento` (
  `dep_id` int(11) NOT NULL,
  `dep_nom` varchar(150) NOT NULL,
  `dep_codigo` varchar(150) NOT NULL,
  `est` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `tm_departamento`
--

INSERT INTO `tm_departamento` (`dep_id`, `dep_nom`, `dep_codigo`, `est`) VALUES
(1, 'Recursos Humanos', 'RH', 1),
(2, 'Finanzas', 'FINZ', 1),
(3, 'Ama de llaves', 'GMALL', 1),
(4, 'Restaurante', 'REST', 1),
(5, 'Soporte', 'SYS', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_notificacion`
--

CREATE TABLE `tm_notificacion` (
  `not_id` int(11) NOT NULL,
  `usu_id` int(11) NOT NULL,
  `not_mensaje` varchar(400) NOT NULL,
  `tick_id` int(11) NOT NULL,
  `est` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `tm_notificacion`
--

INSERT INTO `tm_notificacion` (`not_id`, `usu_id`, `not_mensaje`, `tick_id`, `est`) VALUES
(1, 1, 'Tiene una nueva respuesta de soporte del ticket Nro : ', 43, 1),
(2, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 43, 1),
(3, 1, 'Tiene una nueva respuesta de soporte del ticket Nro : ', 43, 1),
(4, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 43, 1),
(5, 1, 'Tiene una nueva respuesta de soporte del ticket Nro : ', 43, 1),
(6, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 43, 1),
(7, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 43, 1),
(8, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 43, 1),
(9, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 43, 1),
(10, 11, 'Se le ha asignado el ticket Nro : ', 44, 1),
(11, 1, 'Tiene una nueva respuesta de soporte del ticket Nro : ', 44, 1),
(12, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 44, 1),
(13, 11, 'Se le ha asignado el ticket Nro : ', 45, 1),
(14, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 45, 1),
(15, 1, 'Tiene una nueva respuesta de soporte del ticket Nro : ', 45, 1),
(16, 11, 'Se le ha asignado el ticket Nro : ', 46, 1),
(17, 1, 'Tiene una nueva respuesta de soporte del ticket Nro : ', 45, 1),
(18, 11, 'Se le ha asignado el ticket Nro : ', 48, 1),
(19, 11, 'Se le ha asignado el ticket Nro : ', 49, 1),
(20, 1, 'Tiene una nueva respuesta de soporte del ticket Nro : ', 49, 1),
(21, 1, 'Tiene una nueva respuesta de soporte del ticket Nro : ', 49, 1),
(22, 1, 'Tiene una nueva respuesta de soporte del ticket Nro : ', 49, 1),
(23, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(24, 1, 'Tiene una nueva respuesta de soporte del ticket Nro : ', 49, 1),
(25, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(26, 1, 'Tiene una nueva respuesta de soporte del ticket Nro : ', 49, 1),
(27, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(28, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(29, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(30, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(31, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(32, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(33, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(34, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(35, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(36, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(37, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(38, 1, 'Tiene una nueva respuesta de soporte del ticket Nro : ', 49, 1),
(39, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(40, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(41, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(42, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(43, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(44, 1, 'Tiene una nueva respuesta de soporte del ticket Nro : ', 49, 1),
(45, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(46, 1, 'Tiene una nueva respuesta de soporte del ticket Nro : ', 49, 1),
(47, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(48, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(49, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(50, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(51, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(52, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(53, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(54, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(55, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(56, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(57, 1, 'Tiene una nueva respuesta de soporte del ticket Nro : ', 49, 1),
(58, 1, 'Tiene una nueva respuesta de soporte del ticket Nro : ', 49, 1),
(59, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(60, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(61, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(62, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1),
(63, 11, 'Tiene una nueva respuesta del usuario con nro de ticket : ', 49, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_prioridad`
--

CREATE TABLE `tm_prioridad` (
  `prio_id` int(11) NOT NULL,
  `prio_nom` varchar(50) NOT NULL,
  `est` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `tm_prioridad`
--

INSERT INTO `tm_prioridad` (`prio_id`, `prio_nom`, `est`) VALUES
(1, 'Bajo', 1),
(2, 'Medio', 1),
(3, 'Alto', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_subcategoria`
--

CREATE TABLE `tm_subcategoria` (
  `cats_id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `cats_nom` varchar(150) NOT NULL,
  `est` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `tm_subcategoria`
--

INSERT INTO `tm_subcategoria` (`cats_id`, `cat_id`, `cats_nom`, `est`) VALUES
(1, 1, 'Teclado', 0),
(2, 1, 'Monitor', 0),
(3, 2, 'winrar', 0),
(4, 2, 'VSCODE', 0),
(5, 3, 'Corte de red', 0),
(6, 3, 'Corte de energía ', 0),
(7, 4, 'Actualización de carpeta cliente', 0),
(8, 4, 'Instalación de programa ', 0),
(9, 5, 'Impresora', 1),
(10, 5, 'Encoder', 1),
(11, 5, 'Computadora', 1),
(12, 5, 'Telefono', 1),
(13, 6, 'Posiflex bar', 1),
(14, 6, 'Posiflex familiar', 1),
(15, 6, 'Impresora bar', 1),
(16, 6, 'Impresora familiar', 1),
(17, 6, 'Impresora Lobby', 1),
(18, 6, 'Computadora Lobby', 1),
(19, 7, 'Impresora 1', 1),
(20, 7, 'Impresora 2', 1),
(21, 7, 'Posiflex 1', 1),
(22, 7, 'Posiflex 2', 1),
(23, 7, 'Computadora ', 1),
(24, 7, 'Impresora caja', 1),
(25, 8, 'Impresora 1', 1),
(26, 8, 'Impresora 2', 1),
(27, 8, 'Posiflex 1', 1),
(28, 8, 'Posiflex 2', 1),
(29, 8, 'Computadora', 1),
(30, 8, 'Impresora caja', 1),
(31, 9, 'Impresora 1', 1),
(32, 9, 'Impresora 2', 1),
(33, 9, 'Posiflex 1', 1),
(34, 9, 'Posiflex 2', 1),
(35, 9, 'Impresora caja', 1),
(36, 9, 'Computadora', 1),
(37, 10, 'Computadora', 1),
(38, 10, 'Teléfono', 1),
(39, 11, 'Televisiones ', 1),
(40, 11, 'Teléfono', 1),
(41, 12, 'Computadora', 1),
(42, 12, 'Impresora', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_ticket`
--

CREATE TABLE `tm_ticket` (
  `tick_id` int(11) NOT NULL,
  `usu_id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `cats_id` int(11) NOT NULL,
  `tick_titulo` varchar(250) NOT NULL,
  `tick_descrip` varchar(9000) NOT NULL,
  `tick_estado` varchar(15) DEFAULT NULL,
  `fech_crea` datetime DEFAULT NULL,
  `usu_asig` int(11) DEFAULT NULL,
  `fech_asig` datetime DEFAULT NULL,
  `tick_estre` int(11) DEFAULT NULL,
  `tick_coment` varchar(300) DEFAULT NULL,
  `fech_cierre` datetime DEFAULT NULL,
  `prio_id` int(11) DEFAULT NULL,
  `est` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `tm_ticket`
--

INSERT INTO `tm_ticket` (`tick_id`, `usu_id`, `cat_id`, `cats_id`, `tick_titulo`, `tick_descrip`, `tick_estado`, `fech_crea`, `usu_asig`, `fech_asig`, `tick_estre`, `tick_coment`, `fech_cierre`, `prio_id`, `est`) VALUES
(49, 1, 6, 15, 'Prueba notificacion ', '<p>prueba</p>', 'Abierto', '2023-05-31 11:06:31', 11, '2023-05-31 11:06:47', NULL, NULL, NULL, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tm_usuario`
--

CREATE TABLE `tm_usuario` (
  `usu_id` int(11) NOT NULL,
  `usu_nom` varchar(150) DEFAULT NULL,
  `usu_ape` varchar(150) DEFAULT NULL,
  `usu_correo` varchar(150) NOT NULL,
  `usu_pass` varchar(150) NOT NULL,
  `rol_id` int(11) DEFAULT NULL,
  `dep_id` int(11) NOT NULL,
  `fech_crea` datetime DEFAULT NULL,
  `fech_modi` datetime DEFAULT NULL,
  `fech_elim` datetime DEFAULT NULL,
  `est` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci COMMENT='Tabla Mantenedor de Usuarios';

--
-- Volcado de datos para la tabla `tm_usuario`
--

INSERT INTO `tm_usuario` (`usu_id`, `usu_nom`, `usu_ape`, `usu_correo`, `usu_pass`, `rol_id`, `dep_id`, `fech_crea`, `fech_modi`, `fech_elim`, `est`) VALUES
(1, 'Jose', 'Aguilar', 'jmaguilar_123@hotmail.com', '202cb962ac59075b964b07152d234b70', 1, 2, NULL, NULL, NULL, 1),
(11, 'Soporte Hotsson', 'Acapulco', 'hotel_hotsson@hotmail.com', 'e10adc3949ba59abbe56e057f20f883e', 2, 5, '2023-05-03 14:34:12', NULL, NULL, 1),
(38, 'Perfil', 'Prueba 3', 'jmaguilar_12@hotmail.com', 'd9b1d7db4cd6e70935368a1efb10e377', 1, 2, '2023-05-30 10:03:43', NULL, NULL, 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `td_documento`
--
ALTER TABLE `td_documento`
  ADD PRIMARY KEY (`doc_id`);

--
-- Indices de la tabla `td_documento_detalle`
--
ALTER TABLE `td_documento_detalle`
  ADD PRIMARY KEY (`det_id`);

--
-- Indices de la tabla `td_ticketdetalle`
--
ALTER TABLE `td_ticketdetalle`
  ADD PRIMARY KEY (`tickd_id`);

--
-- Indices de la tabla `tm_categoria`
--
ALTER TABLE `tm_categoria`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indices de la tabla `tm_departamento`
--
ALTER TABLE `tm_departamento`
  ADD PRIMARY KEY (`dep_id`);

--
-- Indices de la tabla `tm_notificacion`
--
ALTER TABLE `tm_notificacion`
  ADD PRIMARY KEY (`not_id`);

--
-- Indices de la tabla `tm_prioridad`
--
ALTER TABLE `tm_prioridad`
  ADD PRIMARY KEY (`prio_id`);

--
-- Indices de la tabla `tm_subcategoria`
--
ALTER TABLE `tm_subcategoria`
  ADD PRIMARY KEY (`cats_id`);

--
-- Indices de la tabla `tm_ticket`
--
ALTER TABLE `tm_ticket`
  ADD PRIMARY KEY (`tick_id`);

--
-- Indices de la tabla `tm_usuario`
--
ALTER TABLE `tm_usuario`
  ADD PRIMARY KEY (`usu_id`),
  ADD UNIQUE KEY `uk_usu_correo` (`usu_correo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `td_documento`
--
ALTER TABLE `td_documento`
  MODIFY `doc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `td_documento_detalle`
--
ALTER TABLE `td_documento_detalle`
  MODIFY `det_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `td_ticketdetalle`
--
ALTER TABLE `td_ticketdetalle`
  MODIFY `tickd_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT de la tabla `tm_categoria`
--
ALTER TABLE `tm_categoria`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `tm_departamento`
--
ALTER TABLE `tm_departamento`
  MODIFY `dep_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `tm_notificacion`
--
ALTER TABLE `tm_notificacion`
  MODIFY `not_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT de la tabla `tm_prioridad`
--
ALTER TABLE `tm_prioridad`
  MODIFY `prio_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `tm_subcategoria`
--
ALTER TABLE `tm_subcategoria`
  MODIFY `cats_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT de la tabla `tm_ticket`
--
ALTER TABLE `tm_ticket`
  MODIFY `tick_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT de la tabla `tm_usuario`
--
ALTER TABLE `tm_usuario`
  MODIFY `usu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
